
function buildCustomUrl(input) {
    console.log(input)
    return input.replace(/\$\{(.*?)\}/g, (match) => {
        let matchValue = match.substring(2, match.length - 1).trim()
        switch (true) {
            case matchValue == "tenant":
                break
            case matchValue == "path":
                break
            case /^date.*$/.test(matchValue):
                matchValue = matchValue.substring(4).trim()
                let dateDescriptionPattern = /^(?:(?<base>now|unix *\d{12}|) *)?(?:at *(?<time>\d{2}:\d{2}:\d{2}) *)?(?<offset>(?: *(?:plus|minus) *\d+ *(?:days?|hours?|minutes?|seconds?) *)+)?(?: *format *(?<format>[ymthsTZ\.\-\:]+))?$/
                let parts = dateDescriptionPattern.exec(matchValue)
                console.log("Value:", matchValue)
                console.log(parts)
                switch (true) {
                    case matchValue.startsWith("now"):
                        matchValue = new Date()
                        break
                    case matchValue.startsWith("midnight"):
                        matchValue = new Date()
                        matchValue.setHours(0, 0, 0, 0)
                        break
                    default:
                        matchValue = new Date()
                        break
                }
                break
            default:
                return matchValue
        }
    })
}


buildCustomUrl("${date now at 16:00:00 plus 1 day minus 1 hour}")
buildCustomUrl("${date unix 123456789012 minus 14 days format yyyy-MM-dd}")
buildCustomUrl("${date format yyyy-MM-dd}")
buildCustomUrl("${datenowat16:00:00plus1dayminus1hourformatyyyy-MM-dd}")
async function connectionTestCC(cc = null, eval) {
    let ccId = cc ?? document.querySelector("[id^=location_id][id$=_input]")?.innerText
    if (!ccId) {
        if (eval) return "No location ID selectable in CI Editor"
        return {success: false, value: "No location ID selectable in CI Editor"}
    }
    if (eval) return cc
    let response = await callXHR("POST", operationsUrl() + "/com.sap.esb.monitoring.connection.test.command.CcConnectionTestCommand", `{"locationId": "${ccId}"}`, "application/json;charset=UTF-8", true)
    if (getDocument(response).querySelector("pingSuccessful").innerHTML == "true") {
        return {success: true, value: true}
    } else if (getDocument(response).querySelector("pingSuccessful").innerHTML == "false") {
        createToast(`${ccId} is not reachable`)
        return {success: true, value: false}
    } else {
        createToast(`Error in CC response`, {className: "twineReject"})
        return {success: false, value: "Error in CC response"}
    }
}

let variables = {
    subaccountBasePath: null
}
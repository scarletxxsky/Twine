function capitalizeFirstLetter(val) {
    return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}

/**
 * Evaluates whether the first version string is greater (1), equal to (0) or lower than (-1) the second
 * @param version
 * @param otherVersion
 * @returns number
 */
function compareVersion(version, otherVersion) {
    if (version?.toLowerCase() == otherVersion?.toLowerCase()) return 0
    if (version == null || otherVersion?.toLowerCase() == "draft") return -1
    else if (otherVersion == null || version?.toLowerCase() == "draft") return 1

    let parts = version.split(".").map(it => parseInt(it))
    let oldParts = otherVersion.split(".").map(it => parseInt(it))

    let year = parts[0] > oldParts[0] ? 1 : parts[0] === oldParts[0] ? 0 : -1
    let month = parts[1] > oldParts[1] ? 1 : parts[1] === oldParts[1] ? 0 : -1
    let day = parts[2] > oldParts[2] ? 1 : parts[2] === oldParts[2] ? 0 : -1
    let id = parts[3] ?? 0 > oldParts[3] ?? 0 ? 1 : parts[3] ?? 0 === oldParts[3] ?? 0 ? 0 : -1

    return year > 0 ? 1 : year < 0 ? -1 : month > 0 ? 1 : month < 0 ? -1 : day > 0 ? 1 : day < 0 ? -1 : id > 0 ? 1 : id < 0 ? -1 : 0
}

function getVersionComponents(version, delimiter = ".") {
    return version.split(delimiter).map(it => Number(it))
}

function openLinkInNewTab(url, newWindow) {
    chrome.runtime.sendMessage({
        type: newWindow ? "OPEN_IN_WINDOW" : "OPEN_IN_TAB",
        url: prependHost(url)
    }).then(response => {

    }).catch(error => {

    })
}

function decodeHtml(html) {
    let txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}

function getDocument(document) {
    return new DOMParser().parseFromString(document, "application/xml")
}

function msToTime(s) {
    let ms = s % 1000;
    s = (s - ms) / 1000;
    let secs = s % 60;
    s = (s - secs) / 60;
    let mins = s % 60;
    let hrs = (s - mins) / 60;
    let time = (hrs > 0 ? hrs + 'h ' : "") + (mins > 0 ? mins + 'm ' : "") + (secs > 0 ? secs + 's' : "")
    return time.length > 0 ? time : "1s";
}

function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
        const hex = x.toString(16)
        return hex.length === 1 ? '0' + hex : hex
    }).join('')
}

function getGradientColor(colorStops, progress) {
    if (progress <= colorStops[0][0]) {
        const [r, g, b] = colorStops[0][1];
        return `rgb(${r}, ${g}, ${b})`;
    }
    if (progress >= colorStops[colorStops.length - 1][0]) {
        const [r, g, b] = colorStops[colorStops.length - 1][1];
        return `rgb(${r}, ${g}, ${b})`;
    }

    for (let i = 0; i < colorStops.length - 1; i++) {
        const [startPercent, startColor] = colorStops[i];
        const [endPercent, endColor] = colorStops[i + 1];

        if (progress >= startPercent && progress <= endPercent) {
            const ratio = (progress - startPercent) / (endPercent - startPercent);

            const r = Math.round(startColor[0] + ratio * (endColor[0] - startColor[0]));
            const g = Math.round(startColor[1] + ratio * (endColor[1] - startColor[1]));
            const b = Math.round(startColor[2] + ratio * (endColor[2] - startColor[2]));

            return `rgb(${r}, ${g}, ${b})`;
        }
    }
}

function tryParseJSON(jsonString) {
    try {
        let o = JSON.parse(jsonString);

        if (o && typeof o === "object") {
            return o;
        }
    } catch (e) {
    }

    return false;
}

function getTextDuration(text, minDuration) {
    return (((text?.length ?? 0) * 55) + (minDuration ?? 1500))
}


let pathTypeRegex = new RegExp('^(?:[a-z+]+:)?//', 'i')

function isAbsolutePath(path) {
    return pathTypeRegex.test(path)
}

function prependHost(path) {
    if (isAbsolutePath(path)) return path
    return window.location.protocol + "//" + window.location.host + (path.startsWith("/") ? path : "/" + path)
}

function prettyPrintXml(sourceXml) {
    let xmlDoc = new DOMParser().parseFromString(sourceXml, 'application/xml')
    let xsltDoc = new DOMParser().parseFromString([
        // describes how we want to modify the XML - indent everything
        '<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform">',
        '  <xsl:strip-space elements="*"/>',
        '  <xsl:template match="para[content-style][not(text())]">', // change to just text() to strip space in text nodes
        '    <xsl:value-of select="normalize-space(.)"/>',
        '  </xsl:template>',
        '  <xsl:template match="node()|@*">',
        '    <xsl:copy><xsl:apply-templates select="node()|@*"/></xsl:copy>',
        '  </xsl:template>',
        '  <xsl:output indent="yes"/>',
        '</xsl:stylesheet>',
    ].join('\n'), 'application/xml')

    let xsltProcessor = new XSLTProcessor()
    xsltProcessor.importStylesheet(xsltDoc)
    let resultDoc = xsltProcessor.transformToDocument(xmlDoc)
    return new XMLSerializer().serializeToString(resultDoc)
}

class Macro {
    constructor(query) {

    }

    static evaluate() {

    }

    static execute() {

    }
}

async function replaceAsync(str, regex, replacer) {
    const matches = [...str.matchAll(regex)];

    const replacements = await Promise.all(matches.map(async (match) => {
        const result = await replacer(match[1]);
        return {match, result};
    }));

    let newStr = str;
    for (const {match, result} of replacements.reverse()) {
        newStr = newStr.slice(0, match.index) + result + newStr.slice(match.index + match[0].length);
    }

    return newStr;
}

async function resolveDynamic(dynamic, eval) {
    if (dynamic == null) return
    let evaluation = []
    let result = await replaceAsync(dynamic, /\{\{(.*?)}}/g, async (match) => {
        let replace = await resolveParameter(match, eval)
        if (replace.success) {
            if (eval) evaluation.push(replace.value)
            return replace.value
        } else {
            throw new Error(replace)
        }
    })

    if (eval) {
        evaluation.unshift(result)
        return evaluation
    }
    return result
}

let macroRunning = false

async function resolveMacro(macro, eval) {
    if (macroRunning && !eval) {
        createToast("Another macro is already running", {className: "twineWarning"})
        return []
    } else macroRunning = true

    if (macro == null) return []
    let execution = []
    let matches = macro.match(/\{\{(.*?)}}/g)
    if (matches.length == 0) {
        macroRunning = false
        return [macro]
    }

    for (const match of matches) {
        if (execution.length > 0 && (execution[execution.length - 1].success === false)) {
            if (execution.any(it => it.terminate)) execution.push({
                success: false,
                value: "More content after terminating statement"
            })
            return
        }
        execution.push(await resolveParameter(match.slice(2, -2), eval, true, execution))
    }
    macroRunning = false
    return execution
}

async function resolveParameter(parameter, eval) {
    if (parameter.length == 0) {
        if (eval) return "<b>✘</b> Empty parameter"
        return {success: true, value: parameter}
    }
    switch (true) {
        //Tenant/Environment Colors
        case parameter.startsWith("tenantColor"): {
            if (parameter == "tenantColor") {
                return {success: true, value: getTenantColor()}
            } else {
                let tenantId = parameter.match(/\((.*)\)/)
                if (tenantId.length > 0) {
                    tenantId = tenantId[0]
                    let tenant = tenantVariables.globalEnvironment.tenants.filter(it => it.id == tenantId)
                    if (tenant.length > 0) {
                        return {success: true, value: tenant[0].color}
                    } else {
                        if (eval) return `<b>✘</b> Tenant ${tenantId} not found in environment`
                        return {success: false, value: `Tenant ${tenantId} not found in environment`}
                    }
                } else {
                    return {success: true, value: parameter}
                }
            }
        }
        //User Value
        case /constant\(.+\)/.test(parameter):
            let id = parameter.match(/\((.+)\)/)
            if (id.length > 0) {
                id = id[1]
                let constant = configuration.overrides.constant[id]
                if (constant) {
                    return {success: true, value: constant}
                } else {
                    if (eval) return `<b>✘</b> Constant ${id} not found`
                    return {success: false, value: `Constant ${id} not found`}
                }
            } else {
                if (eval) return "<b>✘</b> Empty Constant ID"
                return {success: false, value: `Empty Constant ID`}
            }
        case /var\(.+\)/.test(parameter):
            let token = parameter.match(/\((.+)\)/)
            if (token.length > 0) {
                token = token[1]
                let variable = variables[token]
                if (variable) {
                    return {success: true, value: variable}
                } else {
                    if (eval) return `<b>✘</b> Unknown Variable ${token}`
                    return {success: false, value: `Unknown Variable ${token}`}
                }
            } else {
                if (eval) return "<b>✘</b> Empty Variable ID"
                return {success: false, value: `Empty Variable ID`}
            }
        case /date/.test(parameter):
            return {success: true, value: new Date().toLocaleDateString()}
        case parameter.startsWith("pingCC"): {
            if (parameter == "pingCC") {
                if (eval) return "Ping location ID in IFlow Adapter: " + await connectionTestCC(null, eval)
                return {success: true, value: connectionTestCC()}
            } else {
                let ccId = parameter.match(/\((.+)\)/)
                if (ccId != null) {
                    ccId = ccId[1]
                    if (eval) return `Ping location ID "${ccId[1]}"`
                    return {success: true, value: await connectionTestCC(ccId)}
                } else {
                    if (eval) return "<b>✘</b> Missing location ID"
                    return {success: false, value: `Missing location ID`}
                }
            }
        }
        case /delay\(.+\)/.test(parameter): {
            let delay = parameter.match(/\((.+)\)/)
            if (delay.length > 0) {
                delay = delay[1]
                if (eval) return `Delay ${delay}ms`
                return await new Promise(resolve => setTimeout(resolve, delay)).then(() => {
                    return {success: true}
                }).catch(error => {
                    return {success: false, value: error}
                })
            } else {
                if (eval) return "<b>✘</b> No delay specified"
                return {success: false, value: `No delay specified`}
            }
        }
        case /(open|navigate)\(.*\)/.test(parameter): {
            let urlMatch = parameter.match(/\((.+)\)/)
            if (urlMatch.length > 0) {
                let url = urlMatch[1]
                if (eval) return urlMatch == "open" ? `Open ${url} in new tab` : `Navigate to ${url}`
                return {success: true, terminate: () => { urlMatch == "open" ? openLinkInNewTab(url, false) : window.location.assign(prependHost(url)) }, terminationAction: urlMatch == "open" ? `Open ${url} in new tab` : `Navigate to ${url}`}
            } else {
                if (eval) return "<b>✘</b> No URL specified"
                return {success: false, value: `No URL specified`}
            }
        }
        case parameter == "prompt" : {
            return {success: false, value: "Not implemented"}
        }
        case /copy\(.+\)/.test(parameter): {
            return {success: false, value: "Not implemented"}
        }
        default: {
            if (eval) return `<b>✘</b> Unresolved parameter or function call`
            return {success: false, value: `Unresolved parameter or function call ${parameter}`}
        }
    }
}
function navigationInfoUrl() {
    return "/manageTenant/is-landing/v1.0/navigationInfo"
}
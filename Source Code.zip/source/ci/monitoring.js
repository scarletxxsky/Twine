let activateTraceExamplePayload = {"artifactSymbolicName":"PKG001_IF008_SAP_ERP_to_Salesforce_ReplicateProductHierarchy_DEV","mplLogLevel":"TRACE","nodeType":"IFLMAP" , "runtimeLocationId": "cloudintegration"}
/**
 * URL = logLevelUrl
 * Method = POST
 * CSRF = true
 * Runtime Location IDs = cloudintegration, edge (?)
 * Artifact Symbolic Name = Artifact ID
 * MPL Log Level = Log Level in all caps
 * Node Type = IFLMAP (Constant?)
 */
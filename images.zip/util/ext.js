function capitalizeFirstLetter(val) {
    return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}

/**
 * Evaluates whether the first version string is greater (1), equal to (0) or lower than (-1) the second
 * @param version
 * @param otherVersion
 * @returns number
 */
function compareVersion(version, otherVersion) {
    if (version?.toLowerCase() == otherVersion?.toLowerCase()) return 0
    if (version == null || otherVersion?.toLowerCase() == "draft") return -1
    else if (otherVersion == null || version?.toLowerCase() == "draft") return 1

    let parts = version.split(".").map(it => parseInt(it))
    let oldParts = otherVersion.split(".").map(it => parseInt(it))

    let year = parts[0] > oldParts[0] ? 1 : parts[0] === oldParts[0] ? 0 : -1
    let month = parts[1] > oldParts[1] ? 1 : parts[1] === oldParts[1] ? 0 : -1
    let day = parts[2] > oldParts[2] ? 1 : parts[2] === oldParts[2] ? 0 : -1
    let id = parts[3] ?? 0 > oldParts[3] ?? 0 ? 1 : parts[3] ?? 0 === oldParts[3] ?? 0 ? 0 : -1

    return year > 0 ? 1 : year < 0 ? -1 : month > 0 ? 1 : month < 0 ? -1 : day > 0 ? 1 : day < 0 ? -1 : id > 0 ? 1 : id < 0 ? -1 : 0
}

function getVersionComponents(version, delimiter = ".") {
    return version.split(delimiter).map(it => Number(it))
}

function openLinkInNewTab(url, newWindow) {
    chrome.runtime.sendMessage({
        type: newWindow ? "OPEN_IN_WINDOW" : "OPEN_IN_TAB",
        url: prependHost(url)
    }).then(response => {

    }).catch(error => {

    })
}

function decodeHtml(html) {
    let txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}

function getDocument(document) {
    return new DOMParser().parseFromString(document, "application/xml")
}

function msToTime(s) {
    let ms = s % 1000;
    s = (s - ms) / 1000;
    let secs = s % 60;
    s = (s - secs) / 60;
    let mins = s % 60;
    let hrs = (s - mins) / 60;
    let time = (hrs > 0 ? hrs + 'h ' : "") + (mins > 0 ? mins + 'm ' : "") + (secs > 0 ? secs + 's' : "")
    return time.length > 0 ? time : "1s";
}

function getGradientColor(colorStops, progress) {
    if (progress <= colorStops[0][0]) {
        const [r, g, b] = colorStops[0][1];
        return `rgb(${r}, ${g}, ${b})`;
    }
    if (progress >= colorStops[colorStops.length - 1][0]) {
        const [r, g, b] = colorStops[colorStops.length - 1][1];
        return `rgb(${r}, ${g}, ${b})`;
    }

    for (let i = 0; i < colorStops.length - 1; i++) {
        const [startPercent, startColor] = colorStops[i];
        const [endPercent, endColor] = colorStops[i + 1];

        if (progress >= startPercent && progress <= endPercent) {
            const ratio = (progress - startPercent) / (endPercent - startPercent);

            const r = Math.round(startColor[0] + ratio * (endColor[0] - startColor[0]));
            const g = Math.round(startColor[1] + ratio * (endColor[1] - startColor[1]));
            const b = Math.round(startColor[2] + ratio * (endColor[2] - startColor[2]));

            return `rgb(${r}, ${g}, ${b})`;
        }
    }
}

function tryParseJSON(jsonString) {
    try {
        let o = JSON.parse(jsonString);

        if (o && typeof o === "object") {
            return o;
        }
    } catch (e) {
    }

    return false;
}

function getTextDuration(text, minDuration) {
    return (((text?.length ?? 0) * 55) + (minDuration ?? 1500))
}


let pathTypeRegex = new RegExp('^(?:[a-z+]+:)?//', 'i')

function isAbsolutePath(path) {
    return pathTypeRegex.test(path)
}

function prependHost(path) {
    if (isAbsolutePath(path)) return path
    return window.location.protocol + "//" + window.location.host + (path.startsWith("/") ? path : "/" + path)
}

function formatDate(date, pattern) {
    const options = {
        'yyyy': date.getFullYear(),
        'MM': String(date.getMonth() + 1).padStart(2, '0'),
        'dd': String(date.getDate()).padStart(2, '0'),
        'HH': String(date.getHours()).padStart(2, '0'),
        'hh': String(date.getHours()),
        'mm': String(date.getMinutes()).padStart(2, '0'),
        'ss': String(date.getSeconds()).padStart(2, '0'),
        'sss': String(date.getMilliseconds()).padStart(2, '0'),

    };

    return pattern.replace(/yyyy|MM|dd|HH|hh|mm|sss|ss/g, match => options[match]);
}

const offsets = Object.freeze({
    "monday": 1,
    "tuesday": 2,
    "wednesday": 3,
    "thursday": 4,
    "friday": 5,
    "saturday": 6,
    "sunday": 0
})
function applyOffsets(date, offsetsStr) {
    const applyOffset = (date, offset) => {
        const matchWeekday = /^LAST_(\w+)$/i   // LAST_DAY
        const matchNextWeekday = /^NEXT_(\w+)$/i // NEXT_DAY
        const matchOffset = /^([+-]?\d+)(day|hour|minute)s?$/i
        const matchDate = /^D(\d{4})-(\d{2})-(\d{2})$/i
        const matchTime = /^T(\d{2}):(\d{2}):(\d{2})$/i

        const matchLast = offset.match(matchWeekday)
        if (matchLast) {
            const dayName = matchLast[1].toLowerCase()
            const targetDay = offsets[dayName]
            if (targetDay !== undefined) {
                const dayOfWeek = date.getDay()
                const daysToSubtract = (dayOfWeek - targetDay + 7) % 7 || 7
                date.setDate(date.getDate() - daysToSubtract)
            }
        }

        const matchNext = offset.match(matchNextWeekday)
        if (matchNext) {
            const dayName = matchNext[1].toLowerCase()
            const targetDay = offsets[dayName]
            if (targetDay !== undefined) {
                const dayOfWeek = date.getDay()
                const daysToAdd = (targetDay - dayOfWeek + 7) % 7 || 7
                date.setDate(date.getDate() + daysToAdd)
            }
        }

        const matchConcreteOffset = offset.match(matchOffset)
        if (matchConcreteOffset) {
            const offset = parseInt(matchConcreteOffset[1])
            switch (matchConcreteOffset[2].toLowerCase()) {
                case "minute":
                    date.setMinutes(date.getMinutes() + offset)
                    break
                case "hour":
                    date.setHours(date.getHours() + offset)
                    break
                case "day":
                    date.setDate(date.getDate() + offset)
                    break
            }
        }

        const matchTimeOffset = offset.match(matchTime)
        if (matchTimeOffset) {
            const [, hours, minutes, seconds] = matchTimeOffset
            date.setHours(parseInt(hours))
            date.setMinutes(parseInt(minutes))
            date.setSeconds(parseInt(seconds))
        }

        const matchDateOffset = offset.match(matchDate)
        if (matchDateOffset) {
            const [, years, months, days] = matchDateOffset
            date.setFullYear(parseInt(years))
            date.setMonth(parseInt(months))
            date.setDate(parseInt(days))
        }
    }

    let offsetDate = new Date(date.getTime())
    offsetsStr.split(',').forEach(offset => applyOffset(offsetDate, offset.trim()))
    return offsetDate
}

function prettyPrintXml(sourceXml) {
    let xmlDoc = new DOMParser().parseFromString(sourceXml, 'application/xml')
    let xsltDoc = new DOMParser().parseFromString([
        // describes how we want to modify the XML - indent everything
        '<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform">',
        '  <xsl:strip-space elements="*"/>',
        '  <xsl:template match="para[content-style][not(text())]">', // change to just text() to strip space in text nodes
        '    <xsl:value-of select="normalize-space(.)"/>',
        '  </xsl:template>',
        '  <xsl:template match="node()|@*">',
        '    <xsl:copy><xsl:apply-templates select="node()|@*"/></xsl:copy>',
        '  </xsl:template>',
        '  <xsl:output indent="yes"/>',
        '</xsl:stylesheet>',
    ].join('\n'), 'application/xml')

    let xsltProcessor = new XSLTProcessor()
    xsltProcessor.importStylesheet(xsltDoc)
    let resultDoc = xsltProcessor.transformToDocument(xmlDoc)
    return new XMLSerializer().serializeToString(resultDoc)
}

class Macro {
    constructor(query) {

    }

    static evaluate() {

    }

    static execute() {

    }
}

async function replaceAsync(str, regex, replacer) {
    const matches = [...str.matchAll(regex)];

    const replacements = await Promise.all(matches.map(async (match) => {
        const result = await replacer(match[1]);
        return {match, result};
    }));

    let newStr = str;
    for (const {match, result} of replacements.reverse()) {
        newStr = newStr.slice(0, match.index) + result + newStr.slice(match.index + match[0].length);
    }

    return newStr;
}

async function resolveDynamic(dynamic, eval) {
    if (dynamic == null) return
    let evaluation = []
    let result = await replaceAsync(dynamic, /\{\{(.*?)}}/g, async (match) => {
        let replace = await resolveParameter(match, eval)
        if (replace.success) {
            if (eval) evaluation.push(replace.value)
            return replace.value
        } else {
            if (eval) evaluation.push(replace)
        }
    })

    if (eval) {
        return evaluation
    }
    return result
}

let macroRunning = false

async function resolveMacro(macro, eval) {
    if (macroRunning && !eval) {
        createToast("Another macro is already running", {className: "twineWarning"})
        return []
    } else macroRunning = true

    if (macro == null) return []
    let execution = []
    let matches = macro.match(/\{\{(.*?)}}/g)
    if (!matches || matches.length == 0) {
        macroRunning = false
        return [macro]
    }

    for (const match of matches) {
        console.log(execution)
        if (execution.length > 0 && (execution[execution.length - 1].success === false)) {
            if (execution.any(it => it.terminate)) execution.push({
                success: false,
                value: "More content after terminating statement"
            })
            return
        }
        execution.push(await resolveParameter(match.slice(2, -2), eval, execution))
        console.log(execution)
    }
    macroRunning = false
    return execution
}

async function resolveParameter(parameter, eval, context) {
    if (parameter.length == 0) {
        if (eval) return "<b>✘</b> Empty parameter"
        return {success: true, value: parameter}
    }
    switch (true) {
        //Tenant/Environment Colors
        case parameter.startsWith("tenantColor"): {
            if (parameter == "tenantColor") {
                return {success: true, value: getTenantColor()}
            } else {
                let tenantId = parameter.match(/\((.*)\)/)
                if (tenantId.length > 0) {
                    tenantId = tenantId[0]
                    let tenant = tenantVariables.globalEnvironment.tenants.filter(it => it.id == tenantId)
                    if (tenant.length > 0) {
                        return {success: true, value: tenant[0].color}
                    } else {
                        if (eval) return `<b>✘</b> Tenant ${tenantId} not found in environment`
                        return {success: false, value: `Tenant ${tenantId} not found in environment`}
                    }
                } else {
                    return {success: true, value: parameter}
                }
            }
        }
        //User Value
        case /constant\(.+\)/.test(parameter):
            let id = parameter.match(/\((.+)\)/)
            if (id.length > 0) {
                id = id[1]
                let constant = JSON.parse(settingsDialog.tabs[2].getSaveOutput()).constant?.[id]
                if (constant) {
                    console.log(constant)
                    if (eval) return JSON.stringify(constant)
                    return {success: true, value: constant}
                } else {
                    if (eval) return `<b>✘</b> Constant <b>${id}</b> not found`
                    return {success: false, value: `Constant ${id} not found`}
                }
            } else {
                if (eval) return "<b>✘</b> Empty Constant ID"
                return {success: false, value: `Empty Constant ID`}
            }
        case /var\(.+\)/.test(parameter):
            let token = parameter.match(/\((.+)\)/)
            if (token.length > 0) {
                token = token[1]
                let variable = variables[token]
                if (variable === undefined) {
                    if (eval) return `<b>✘</b> Unknown variable <b>${token}</b>`
                    return {success: false, value: `Unknown variable ${token}`}
                } else if (variable === null) {
                    if (eval) return `<b>✘</b> Variable <b>${token}</b> not initialized`
                    return {success: false, value: `Variable ${token} not initialized`}
                } else{
                    if (eval) variable.toString()
                    return {success: true, value: variable}
                }
            } else {
                if (eval) return "<b>✘</b> Empty variable ID"
                return {success: false, value: `Empty variable ID`}
            }
        case parameter.startsWith("date"): {
            let date = new Date()
            if (parameter == "date") {
                if (eval) return new Date().toISOString()
                return {success: true, value: new Date().toISOString()}
            } else {
                let dateModifiers = parameter.match(/\((.+)\)/)
                if (dateModifiers != null) {
                    let [offset, format] = dateModifiers[1].split("|")
                    let dateWithOffset = offset ? applyOffsets(date, offset) : null
                    let dateWithPattern = format ? formatDate(dateWithOffset ?? date, format) : null
                    if (eval) return `Use UTC date (${date.toISOString()})${dateWithOffset ? `, apply offset (${dateWithOffset.toISOString()})` : ""} ${dateWithPattern ? `, apply pattern (${dateWithPattern})` : ""}`
                    return {success: true, value: `Apply modifiers to date "${dateModifiers}"`}
                } else {
                    if (eval) return `<b>✘</b> Trailing content (<b>${parameter.replace(/date\(?\)?/, "")}</b>) after date function`
                    return {success: false, value: new Date().toISOString()}
                }
            }
        }
        case parameter.startsWith("pingCC"): {
            if (parameter == "pingCC") {
                if (eval) return "Ping location ID in IFlow Adapter: " + await connectionTestCC(null, eval)
                return {success: true, value: connectionTestCC()}
            } else {
                let ccId = parameter.match(/\((.+)\)/)
                if (ccId != null) {
                    ccId = ccId[1]
                    if (eval) return `Ping location ID "${ccId[1]}"`
                    return {success: true, value: await connectionTestCC(ccId)}
                } else {
                    if (eval) return "<b>✘</b> Missing location ID"
                    return {success: false, value: `Missing location ID`}
                }
            }
        }
        case /delay\(.+\)/.test(parameter): {
            let delay = parameter.match(/\((.+)\)/)
            if (delay.length > 0) {
                delay = delay[1]
                if (eval) return `Delay ${delay}ms`
                return await new Promise(resolve => setTimeout(resolve, delay)).then(() => {
                    return {success: true}
                }).catch(error => {
                    return {success: false, value: error}
                })
            } else {
                if (eval) return "<b>✘</b> No delay specified"
                return {success: false, value: `No delay specified`}
            }
        }
        case /(open|navigate)\(.*\)/.test(parameter): {
            if (context == null) {
                if (eval) return "<b>✘</b> Function <b>open/navigate<b></b> can only be used as a macro"
                return {success: false, value: "open/navigate can only be used as a macro"}
            }
            let urlMatch = parameter.match(/(.*)\((.+)\)/)
            if (urlMatch.length > 0) {
                let url = urlMatch[2]
                let tokens = [...url.matchAll(/(?<!\\)\$(\d+)/g)].map(it => parseInt(it[1])).sort().reverse()
                let invalidTokens = []
                tokens.forEach(token => {
                    console.log(context)
                    let replacement = context[token]
                    if (!replacement) {
                        invalidTokens.push(token)
                    } else {
                        url = url.replace(`$${token}`, context[token].value)
                    }
                })
                if (invalidTokens.length > 0) {
                    if (eval) return `Macro contains invalid tokens: ${invalidTokens.join(", ")}`
                    return {success: false, value: `Macro contains invalid tokens: ${invalidTokens.join(", ")}`}
                }
                if (urlMatch[1] == "open") {
                    if (eval) `Navigate to ${url}`
                    return {success: true, value: window.location.assign(prependHost(url))}
                } else {
                    if (eval) `Open ${url} in new tab`
                    return {
                        success: true, terminate: () => {
                            openLinkInNewTab(url, false)
                        }, terminationAction: `Open ${url} in new tab`
                    }
                }
            } else {
                if (eval) return "<b>✘</b> No URL specified"
                return {success: false, value: `No URL specified`}
            }
        }
        case parameter == "prompt" : {
            return {success: false, value: "Not implemented"}
        }
        case /copy\(.+\)/.test(parameter): {
            return {success: false, value: "Not implemented"}
        }
        default: {
            if (eval) return `<b>✘</b> Unresolved parameter or function call <b>${parameter}</b>`
            return {success: false, value: `Unresolved parameter or function call ${parameter}`}
        }
    }
}

function run(macro, id) {
    resolveMacro(macro, true).then(it => {
        console.log(id + "\n" + it + "\n")
    })
}
